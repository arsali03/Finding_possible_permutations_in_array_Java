/*
    Ali Arslan
    1210505017

    1) Farklı tamsayılardan oluşan bir dizi verildiğinde, tüm olası permütasyonları
    döndürün. Cevabı istediğiniz sırayla döndürebilirsiniz.
*/



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        List<String> nesneler = new ArrayList<String>();


        Scanner girdi = new Scanner(System.in);

        System.out.println("Kaç eleman gireceksiniz?");
        int elemanSayisi = girdi.nextInt();
        String dizi[] = new String [elemanSayisi+1];

        int i;
        System.out.println("Lütfen dizi elemanlarını giriniz:");
        for ( i=0; i <= elemanSayisi; i++)
        {
            dizi[i]=girdi.nextLine();

        }

        for ( i=1; i <= elemanSayisi; i++)
        {
            nesneler.add(dizi[i]);
        }


        System.out.println("Permutasyon: Kaç farklı şekilde dizilirler?");
        Permutasyonlar<String> permutasyonlar = new Permutasyonlar<String>(nesneler);
        for (List<String> permutasyon : permutasyonlar) {
            System.out.println(permutasyon);
        }



    }
}
