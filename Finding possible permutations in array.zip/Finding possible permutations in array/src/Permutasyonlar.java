/*
    Ali Arslan
    1210505017

*/

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

public class Permutasyonlar<T> implements Iterable<List<T>> {

    PermutasyonUretici pUretici;
    T[] elemanlar;
    int[] indeksler;

    public Permutasyonlar(List<T> list) {
        pUretici = new PermutasyonUretici(list.size());
        elemanlar = (T[]) list.toArray();
    }

    @Override
    public Iterator<List<T>> iterator() {
        return new Iterator<List<T>>() {

            int pos = 0;

            @Override
            public boolean hasNext() {
                return pUretici.dahaFazla();
            }

            @Override
            public List<T> next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                indeksler = pUretici.getSonraki();
                List<T> permutasyon = new ArrayList<T>();
                for (int i = 0; i < indeksler.length; i++) {
                    permutasyon.add(elemanlar[indeksler[i]]);
                }
                return permutasyon;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    private final class PermutasyonUretici {

        private int[] a;
        private BigInteger solNumara;
        private BigInteger toplam;

        //-----------------------------------------------------------
                // Yapıcı.
                // UYARI: n'yi çok büyük yapmayın.
                // Permütasyon sayısının n olduğunu hatırlayın!
                // n 20 kadar küçük olsa bile çok büyük olabilir
                // 20! = 2.432.902.008.176.640.000 ve
                // 21! bir Java uzunluğuna sığmayacak kadar büyük, ki bu da
                // bunun yerine neden BigInteger kullanıyoruz.
        //----------------------------------------------------------
        public PermutasyonUretici(int n) {
            if (n < 1) {
                throw new IllegalArgumentException("Kümenin en az bir öğesi olmalıdır");
            }
            a = new int[n];
            toplam = getFaktoriyel(n);
            sifirla();
        }

        //------
        // Sıfırla
        //------
        public void sifirla() {
            for (int i = 0; i < a.length; i++) {
                a[i] = i;
            }
            solNumara = new BigInteger(toplam.toString());
        }

        //------------------------------------------------
        // Henüz oluşturulmamış permütasyonların dönüş sayısı
        //------------------------------------------------
        public BigInteger getSolNumara() {
            return solNumara;
        }

        //------------------------------------
        // Toplam permütasyon sayısını döndür
        //------------------------------------
        public BigInteger getTotal() {
            return toplam;
        }

        //-----------------------------
        // daha fazla permütasyon var mı?
        //-----------------------------
        public boolean dahaFazla() {
            return solNumara.compareTo(BigInteger.ZERO) == 1;
        }

        //------------------
        // Faktöriyel hesaplama
        //------------------
        private BigInteger getFaktoriyel(int n) {
            BigInteger fakt = BigInteger.ONE;
            for (int i = n; i > 1; i--) {
                fakt = fakt.multiply(new BigInteger(Integer.toString(i)));
            }
            return fakt;
        }

        //--------------------------------------------------------
        // Sonraki permütasyonu oluştur
        //--------------------------------------------------------
        public int[] getSonraki() {

            if (solNumara.equals(toplam)) {
                solNumara = solNumara.subtract(BigInteger.ONE);
                return a;
            }

            int temp;

            // En büyük indexi bul

            int j = a.length - 2;
            while (a[j] > a[j + 1]) {
                j--;
            }

            // a[k] en küçük tam sayı olacak şekilde k indeksini bulun
            // a[j]'nin sağındaki a[j]'den büyük değer

            int k = a.length - 1;
            while (a[j] > a[k]) {
                k--;
            }

            // a[j] ve a[k] nin değiş tokuşu

            temp = a[k];
            a[k] = a[j];
            a[j] = temp;

            // Permütasyonun kuyruk ucunu j. konumdan sonra artan düzende koyunuz

            int r = a.length - 1;
            int s = j + 1;

            while (r > s) {
                temp = a[s];
                a[s] = a[r];
                a[r] = temp;
                r--;
                s++;
            }

            solNumara = solNumara.subtract(BigInteger.ONE);
            return a;

        }
    }
}

